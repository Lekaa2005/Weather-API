package jvprogram;


	import java.io.*;
	import java.net.*;
	import org.json.*;
	import java.util.*;

	public class api {
	    public static void main(String[] args) {
	    	Scanner scan=new Scanner(System.in);
	    	System.out.print("enter the city name :");
	        String city =scan.next();
	        String apiKey = "5ed55ef76e1fd92c3b4594319eef2932"; 
	        String url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey + "&units=metric";

	        try {
	            HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
	            conn.setRequestMethod("GET");

	            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	            StringBuilder response = new StringBuilder();
	            String line;
	            while ((line = in.readLine()) != null) response.append(line);
	            in.close();

	            JSONObject obj = new JSONObject(response.toString());
	            JSONObject main = obj.getJSONObject("main");
	            String weather = obj.getJSONArray("weather").getJSONObject(0).getString("description");

	            System.out.println("Temp: " + main.getDouble("temp") + "°C");
	            System.out.println("Humidity: " + main.getInt("humidity") + "%");
	            System.out.println("Condition: " + weather);
	        } catch (Exception e) {
	            System.out.println("Error: " + e.getMessage());
	        }
	    }
	}

